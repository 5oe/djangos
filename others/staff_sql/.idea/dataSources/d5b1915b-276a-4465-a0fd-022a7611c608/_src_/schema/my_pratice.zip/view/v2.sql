CREATE VIEW v2 AS
  SELECT
    `my_pratice`.`s1`.`id`     AS `id`,
    `my_pratice`.`s1`.`name`   AS `name`,
    `my_pratice`.`s1`.`gender` AS `gender`,
    `my_pratice`.`s1`.`email`  AS `email`
  FROM `my_pratice`.`s1`
  WHERE (`my_pratice`.`s1`.`id` = 2222222);
